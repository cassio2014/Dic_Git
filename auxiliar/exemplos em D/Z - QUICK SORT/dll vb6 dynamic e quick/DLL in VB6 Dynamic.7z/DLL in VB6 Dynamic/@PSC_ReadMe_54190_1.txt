Title: Create Standard DLLs in Visual Basic  v2 - make your own api
Description: This code will allow you to make your very own stdcall DLL files using Visual Basic. The DLLs that you create can be called from any programming language that supports stdcall DLLs. Just create or open a project with the functions that you want to export, choose the functions to export and click compile! Create your own DLLs that you can call from any programming language that supports stdcall dlls. Create your own API, share code between your programs, create a control panel applet, create an ISAPI application, the possibilities are endless!
[This is the 2nd version of the code available at http://www.planet-source-code.com/vb/scripts/ShowCode.asp?txtCodeId=53476&lngWId=1]
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=54190&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
